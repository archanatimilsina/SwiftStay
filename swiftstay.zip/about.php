<!-- header + navbar -->
<?php  
include("inc/header.php");?>
<!-- header + navbar -->

<!-- about page  -->
 <section id=aboutContent>
  <!-- slider -->
  <div class="a slider">
    <img src="img/about2.avif" width="100%"; height="100%" alt="#">
  </div>
  <!-- slider -->

  <p class="branchTitle">Our Branches</p>
  <!-- Our Branches -->
  
  <div class="a branches">
    <div class="b box1">
<div class="img1">
  <img src="img/about11.avif" width="100%" height="100%" alt="">
</div>
<p class="f bname">Hada Cafe</p>
<p class="f location">Location: Suryabinayak, Bhaktapur</p>
<p class="detail1">Lorem ipsum dollit.m quisquam obcemporibus maxime quas excepturi consequatur, pariatur ratione. Perspiciatis, pra</p>
    </div>
    <div class="b box2">
    <div class="img1">
    <img src="img/about12.avif" width="100%" height="100%" alt="">
    </div> 
    <p class="f bname">Luffy</p>
    <p class="f location">Location: One_piece, Japan</p>
<p class="detail1">Lorem ipsum dollit.m quisquam obcemporibus maxime quas excepturi consequatur, pariatur ratione. Perspiciatis, pra</p>
    </div>
    <div class="b box3">
    <div class="img1">
    <img src="img/about13.avif" width="100%" height="100%" alt="">
    </div>
    <p class="f bname">Usopp</p>
    <p class="f location">Location: One_piece, Japan</p>
<p class="detail1">Lorem ipsum dollit.m quisquam obcemporibus maxime quas excepturi consequatur, pariatur ratione. Perspiciatis, pra</p>
    </div>
  </div>
  <!-- Our Branches -->

  <!-- about -->
  <p class="article">Our Thoughts</p>
  <div class="a about">
    <div class="c abox1">
<div class="d box31">
<div class="e">
<img src="img/user1.avif" width="100%" height="100%" alt="">

</div>
<p class="writer">Director Naruto Uzumaki</p>
<a href="articles/naruto.md"><button>Read Now</button></a>
</div>
<div class="d box32">
<div class="e">
<img src="img/user2.avif" width="100%" height="100%" alt="">

</div>
<p class="writer"> C.E.O Hatake Kakashi</p>
<a href=""><button>Read Now</button></a>
</div>
<div class="d box33">
<div class="e">
<img src="img/user3.avif" width="100%" height="100%" alt="">

</div>
<p class="writer">Roronoa Zoro</p>
<a href=""><button>Read Now</button></a>
</div>
    </div>
    <div class="c abox2">
<div class="d box41">
<div class="e">
<img src="img/user4.avif" width="100%" height="100%" alt="">

</div>
<p class="writer">Monkey D Luffy</p>
<a href=""><button>Read Now</button></a>
</div>
<div class="d box42">
<div class="e">
<img src="img/user5.avif" width="100%" height="100%" alt="">

</div>
<p class="writer">Nico Robin</p>
<a href=""><button>Read Now</button></a>
</div>
<div class="d box43">
<div class="e">
<img src="img/user6.avif" width="100%" height="100%" alt="">

</div>
<p class="writer">Chopper</p>
<a href=""><button>Read Now</button></a>
</div>
    </div>
  </div>
  <!-- about -->
</section>
    <!-- about content -->


















<!-- footer -->
<?php
include("inc/footer.php");
?>
<!-- footer -->
