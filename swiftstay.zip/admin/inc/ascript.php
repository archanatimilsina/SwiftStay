<script>
    function AdminBox() {
      let x = document.getElementById('admin-box');
      if (x.style.display=="none") {
        x.style.display="flex";
      } else {
        x.style.display="none";
      }
    } 
  </script>