<?php 
include("inc/header.php");
include("inc/script.php");
include("inc/footertag.php");
?>