<?php 
include("inc/header.php");
?>

<?php 
include("inc/script.php");
include("inc/footertag.php");
?>