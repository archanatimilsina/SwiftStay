<?php 
include('connection.php');
$nr=$_GET['nr'];
$ci=$_GET['ci'];
$co=$_GET['co'];
$rt=$_GET['rt'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .head{
            text-align: center;
            font-size: 30px;
            font-weight: 200;
             color: #fa9579 ;
        }
        #delux-book{
            width: 50%;
            height: 770px;
            border: solid 1px black;
            margin: auto;
            margin-top: 10px; 
            background-color:#fa9579 ;
        }
        .box-head{
            text-align: center;
            font-size: 30px;

        }
        .user-data
        {
            width: 100%;
           
        }
        .user-data form{
            width: 100%;
        }

        .user-data form table{
            width: 100%;
            display: flex;
            flex-direction: row;
            justify-content: center;
            padding: 10px;
        }
        .user-data form table tr td{
            font-size: 22px;
            margin: 5px;
        }
        .user-data form table tr td input{
            width: 100%;
            height: 30px;
            margin: 10px;
            font-size: 19px;

        }
        #book-button{
            width: 70%;
           margin: 20px 50px;
        }
    
    </style>
</head>
<body>
    <h1 class="head">Please fill up the form first</h1>
<section id="delux-book">
    <h1 class="box-head">
Delux AC Room
    </h1>
    
    <div class="user-data">
        <form action="#" method="POST">
            <table>
                <tr>
                    <td>Status</td>
                    <td><input type="text" placeholder="Available"></td>
                </tr>
                <tr>
                    <td>Roomtype</td>
                    <td><input type="text" value="Delux Ac" name="rt"></td>
                </tr>
                <tr>
                    <td>Name</td>
                    <td><input type="text" name="name"></td>
                </tr>
                <tr>
                    <td>Address</td>
                    <td><input type="text" name="Address"></td>
                </tr>
                <tr>
                    <td>City</td>
                    <td><input type="text" name="city"></td>
                </tr>
                <tr>
                    <td>Phone</td>
                    <td><input type="text" name="phoneno"></td>
                </tr>
                <tr>
                    <td>Email</td>
                    <td><input type="text" name="email"></td>
                </tr>
                <tr>
                    <td>Check In Date</td>
                    <td><input type="text" name="cin" value="<?php  echo $ci;?>"></td>
                </tr>
                <tr>
                    <td>Chech Out Date</td>
                    <td><input type="text" name="cout" value="<?php echo $co;?>"></td>
                </tr>
                <tr>
                    <td>Members</td>
                    <td><input type="text" name="members"></td>
                </tr>
                
                <tr>
                    <td>No Of Room</td>
                    <td><input type="text" name="nr" value="<?php echo $nr;?>"></td>
                </tr>
<tr>
    <td colspan="2">
        <input type="button" value="Book" name="button" id="book-button">
    </td>
</tr>
            </table>
        </form>

    </div>
</section>
</body>
</html>