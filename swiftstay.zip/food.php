<?php  
include("inc/header.php");
include("inc/footer.php");
?>